import React from 'react'

function Login() {
  return (
    
    
    <section class="content-header">
<h1>
General Form Elements
<small>Preview</small>
</h1>
<ol class="breadcrumb">
<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
<li><a href="#">Forms</a></li>
<li class="active">General Elements</li>
</ol>
</section>


  )
}

export default Login