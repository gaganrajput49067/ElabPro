import React from 'react'

const CampCreationMaster = () => {
  return (
   <>
    <div className="content-wrapper" style={{ minHeight: "955.604px" }}>
        <div className="container-fluid">
          <div className="card shadow mb-4 mt-4">
            <div className="card-header py-3">
              <div className="clearfix">
                <h6 className="m-0 font-weight-bold text-primary float-left">
                Camp Creation Master
                </h6>
              </div>
            </div>
            <div className='card-body'>
              <div className='col-sm-2 form-group'>
                
              </div>
            </div>
          </div>
        </div>
      </div>
   </>
  )
}

export default CampCreationMaster