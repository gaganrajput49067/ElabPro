import React from "react";
import DatePicker from "../Components/DatePicker";
function LabPrescription() {
  return (
    <>
      <div className="box box-success form-horizontal">
        <div className="box-header with-border">
          <h3 className="box-title">Patient Registration</h3>
        </div>
        <div className="box-body">
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>

            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Rate Type:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Payment Mode:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
          <div className="row">
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Mobile:
            </label>
            <div className="col-sm-2">
              <input
                type="email"
                className="form-control input-sm "
                id="inputEmail3"
                placeholder="Mobile"
              />
            </div>
            <label htmlFor="inputEmail3" className="col-sm-1 ">
              Centre:
            </label>
            <div className="col-sm-2">
              <select className="form-control input-sm ">
                <option>All Department</option>
                <option>Lab No.</option>
                <option>Barcode No.</option>
                <option>Patient ID</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default LabPrescription;
