import React from "react";
import { useTranslation } from "react-i18next";
const CouponManageApproval = () => {
  const { t } = useTranslation();
  return (
    <>
      <div className="box with-border">
        <div className="box box-header with-border box-success">
          <h3 className="box-title text-center">
            {t("Coupon Manage Approval")}
          </h3>
        </div>

        <div className="box-body"></div>
      </div>
    </>
  );
};

export default CouponManageApproval;
