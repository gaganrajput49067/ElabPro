import { useTranslation } from "react-i18next";
import Input from "../../ChildComponents/Input";
import { SelectBox } from "../../ChildComponents/SelectBox";

import DatePicker from "../Components/DatePicker";
import { useState } from "react";
import Loading from "../util/Loading";
import axios from "axios";
import { toast } from "react-toastify"


const CentreAppointmentSearch=()=>{
    const { t } = useTranslation();
    const [loading,setLoading]=useState(false)
    const DateType = [{ label: 'Entry Date', value: 'hc.EntryDateTime' }, {
        label: 'App Date', value: 'hc.AppDateTime'
    }, {
        label: 'Last Status', value: 'hc.CurrentStatusDate'
    }, { label: 'App ID', value: "hc.AppID" }]
    const searchHandler=()=>{
        setLoading(true);
        setTimeout(()=>{
          setLoading(false);
        },2000)
    }
  return (
    <div className="box with-border">
        <div className="box box-header with-border box-success">
          <h3 className="box-title text-center">{t("Centre Visit Search")}</h3>
        </div>
        <div className="box-body">
                <div className="row">

                    <div className="col-sm-1">
                        <SelectBox
                            name="DateOption"
                            className="form-control input-sm"
                            options={DateType}
                        />
                    </div>
                    <label
                        className="col-sm-1"
                        htmlFor="From"
                        style={{ textAlign: "end" }}
                    >
                        {t("From")} :
                    </label>
                    <div className="col-sm-1">
                        <DatePicker
                            name="FromDate"
                            className="form-control input-sm"
                            date={new Date()}
                        />
                    </div>
                    
                    <label
                        className="col-sm-1"
                        htmlFor="To"
                        style={{ textAlign: "end" }}
                    >
                        {t("To")} :
                    </label>
                    <div className="col-sm-1">
                        <DatePicker
                            name="ToDate"
                            className="form-control input-sm"
                            date={new Date()}
                            />
                    </div>
                    <label
                        className="col-sm-1"
                        htmlFor="Mobile No."
                        style={{ textAlign: "end" }}
                    >
                        Mobile No:
                    </label>
                    <div className="col-sm-1">
                        <Input className="form-control input-sm"
                            max={10} />
                    </div>
                    <label
                        className="col-sm-2"
                        htmlFor="Prebooking No."
                        style={{textAlign:'center'}}
                    >
                        Prebooking No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:
                    </label>
                    <div className="col-sm-1">
                        <Input className="form-control input-sm" />
                    </div>

       </div>
       <div
                    className="row"
                    style={{ display: "flex", justifyContent: "center" }}
                >
                    <div className="col-md-1 col-sm-6 col-xs-12">
                        {loading ? (
                            <Loading />
                        ) : (
                            <button
                                type="button"
                                className="btn btn-block btn-success btn-sm"
                                onClick={searchHandler}
                            >
                                {t("Search")}
                            </button>
                        )}
                    </div>
                    <div className="col-md-1 col-sm-6 col-xs-12">
                        <button
                            type="Excel"
                            className="btn btn-block btn-warning btn-sm"

                        >
                            {t("Export to Excel")}
                        </button>
                    </div>
                </div>
        </div>
        <div className="box-body">
        <div className=" row  hcStatus "  >

<div className="col-sm-2 ">
    <button style={{ height: '16px', width: '16px', backgroundColor: 'white', marginRight: '3px' }}
        onClick={() => {
            
        }} ></button>
    <label htmlFor="Pending" className="control-label">
        {t("Pending")}
    </label>
</div>
<div className="col-sm-2 ">
    <button style={{ height: '16px', width: '16px', backgroundColor: "#4acfee", marginRight: '3px' }}
        onClick={() => {
            
        }}></button>
    <label htmlFor="Booking Completed" className="control-label">
        {t("BookingCompleted")}
    </label>
</div>
<div className="col-sm-2 ">
    <button style={{ height: '16px', width: '16px', backgroundColor:'#E75480', marginRight: '3px' }}
        onClick={() => {
           
        }}></button>
    <label htmlFor="Canceled" className="control-label">
        {t("Canceled")}
    </label>
</div>
      </div>   
        </div>
        <div className="box box-body boottable table-responsive ">
                <div className="row">
                    <table
                        className="table table-bordered table-hover table-striped tbRecord"
                        cellPadding="{0}"
                        cellSpacing="{0}"
                    >
                        <thead className="cf text-center" style={{ zIndex: 99 }}>
                            <tr>
                                <th className="text-center">{t("#")}</th>
                                <th className="text-center">{t("CreateDate")}</th>
                                <th className="text-center">{t("CreateBy")}</th>
                                <th className="text-center">{t("AppDate")}</th>
                                <th className="text-center">{t("PrebookingID")}</th>
                                <th className="text-center">{t("MobileNo")}</th>
                                <th className="text-center">{t("PatientName")}</th>
                                <th className="text-center">{t("State")}</th>
                                <th className="text-center">{t("City")}</th>
                                <th className="text-center">{t("Area")}</th>
                                <th className="text-center">{t("Centre")}</th>
                                <th className="text-center">{t("Status")}</th>
                                </tr>
                        </thead>
                        </table>
                        </div>
                        </div>
    </div>
    )
 }

export default CentreAppointmentSearch